// import VueRouter from 'vue-router'
import { createRouter, createWebHashHistory } from "vue-router";

import Tabbar from "views/tabbar/index.vue";
import PageHeader from "components/PageHeader.vue";
import One from "views/tabbar/One.vue";
import Two from "views/tabbar/Two.vue";
import Three from "views/tabbar/Three.vue";

const routes = [
  {
    path: "/",
    name: "/",
    redirect: "/tabbar",
    component: PageHeader,
    children: [
      {
        path: "tabbar",
        name: "tabbar",
        component: Tabbar,
        redirect: "/tabbar/one",
        children: [
          {
            path: "one",
            name: "one",
            component: () => One,
            meta: { title: "One" },
          },
          {
            path: "two",
            name: "two",
            component: () => Two,
            meta: { title: "Two" },
          },
          {
            path: "three",
            name: "Three",
            component: () => Three,
          },
        ],
      },
    ],
  },
];

const router = createRouter({
  history: createWebHashHistory(),
  routes,
});

// export router

export default router;
