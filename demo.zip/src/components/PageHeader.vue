<template>
  <div>
    <van-nav-bar
      title="标题"
      left-text="返回"
      right-text="按钮"
      :placeholder="true"
      left-arrow
      :fixed="fixed"
      v-bind="$attrs"
    />

  <router-view></router-view>
  </div>
</template>

<script>
import { NavBar, } from 'vant';
import { watch, reactive } from 'vue'
import { useRoute, onBeforeRouteUpdate  } from 'vue-router'


export default {
  props: {
    fixed: {
      type: Boolean,
      default: true
    },
  },
  components: {
    [NavBar.name]: NavBar
  },
  setup () {
    // const router = useRouter()
    const route = useRoute()
    let meta = reactive({})

    watch(
      () => route,
      newParams => {
        console.log('newParams', newParams);
      }
    )

    onBeforeRouteUpdate(to => {
      console.log("to", to );
      meta = to.meta
    });
    
    return {
      meta,
    }
  }
}
</script>

<style lang="scss" scoped>

</style>