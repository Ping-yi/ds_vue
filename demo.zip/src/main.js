import Vue from './core/global_vue'
import Router from './router'
import './core/global_use'


Vue.use(Router).mount('#app')
  
