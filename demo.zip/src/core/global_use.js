import Vue from './global_vue'
import { Button } from 'vant';

Vue.use(Button);

